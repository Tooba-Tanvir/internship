<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style>
    .container {
    display: flex;
    justify-content: center;
    position: absolute;
    top:50%;
    left: 50%;
    transform: translate(-50%, -50%);
    display: grid;
    place-items: center;
    height: 50vh; /* Full viewport height */
    background-color:antiquewhite;
    }
    .link {
            color: blue;
            margin-top: 10px;
    }
</style>
</head>
<body>
    <br><br><br><br><br>
<h1><center>Login</center></h1>
    <div class="container">
    <form action="{{route('loginuser')}} "method="post">
    <!--<form action="{{url('store_user')}}" method="post">-->
    @csrf
    <div class="form-group">
        <label>Username</label> 
        <input type="text" name="username" id="username" placeholder="Username" class="form-control" value="{{$username}}">
    </div>
    <div class="form-group">
        <label>Password</label>
        <input type="password" name="password" id="password" placeholder="password" class="form-control" value="{{$password}}">
    </div>
    <div>

    <div class="form-group">
				<label for="BodyPH_ddlInstituteID" class="control-label">Category:</label>
				<div class="input-group">
					<span class="input-group-addon"><i class="fa fa-university"></i></span>
					<select name="category" id="BodyPH_ddlInstituteID" class="form-control AspireDropDownList">
		            <option selected="selected" value="">Select</option>
		            
		            <option value="doctor">Doctor</option>
		            <option value="patient">Patient</option>
	                </select>
                </div>
                
            </div>
            <button onclick="navigateToDashboard()">Login</button>   
   
    </div>
    </form>
    <a href="{{url('registeration-form')}}">Don't have an account? Register</a>
    @csrf
    </div>
    <script>
    function navigateToDasboard() {
      //  event.preventDefault(); // Prevent the form from submitting the traditional way

        const category = document.getElementById('category').value;

        if (category === 'doctor') {
            window.location.href = {{url('dashboard-form')}};
        } else if (category === 'patient') {
            window.location.href = 'dashboardt-form';
        } else {
            alert('Unknown category');
        }
    }
    </script>
    @csrf
  
</body>
</html>
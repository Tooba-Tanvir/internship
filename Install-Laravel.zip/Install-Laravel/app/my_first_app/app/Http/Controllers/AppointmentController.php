<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\AppointmentModel;
use Illuminate\Support\Facades\Auth;

class AppointmentController extends Controller
{
    public function index()
    {
        $user = Auth::user();
        $appointments = $user->appointments;

        return view('appointments.index', compact('user', 'appointments'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'current_medication' => 'required|string',
            'allergies' => 'nullable|string',
            'notes' => 'nullable|string',
        ]);

        $appointment = Appointment::findOrFail($id);
        $appointment->update($request->all());

        return redirect('/appointments')->with('success', 'Appointment updated successfully.');
    }
    public function getAppointments(){
        $appointments = AppointmentModel::get();
        return view("appointment",compact("appointments"));
    }
}
?>

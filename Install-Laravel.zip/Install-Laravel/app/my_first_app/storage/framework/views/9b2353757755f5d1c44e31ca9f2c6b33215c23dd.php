<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
  <!--  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>-->
    <style>
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            height: 550px;
            width:500px; 
            background-color: antiquewhite;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .link {
            color: blue;
            margin-top: 10px;
        }
        .button {
            background-color: #04AA6D; /* Green */
            border: none;
            color: white;
            padding: 15px 32px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
        }
    </style>
</head>
<body>

    <h4 class="text-center">Register</h4><br>
    <div class="container">
    <?php echo csrf_field(); ?>
    <form action="<?php echo e(route('register-user')); ?> "method="post">
      <!--  <form action="<?php echo e(url('saveuser')); ?>" method="post">-->
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label>Firstname</label>
                <input type="text" name="firstname" id="firstname" placeholder="firstname" class="form-control" value="<?php echo e($firstname); ?>">
            </div>
            <div class="form-group">
                <label>lastname</label>
                <input type="text" name="lastname" id="lastname" placeholder="lastname" class="form-control" value="<?php echo e($lastname); ?>">
            </div>
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" id="username" placeholder="Username" class="form-control" value="<?php echo e($username); ?>">
            </div>
            <div class="form-group double">
               
                <label>Email</label>
                <input type="email" name="email" id="email" placeholder="Email" class="form-control" value="<?php echo e($email); ?>">
            </div>
            <div class="form-group double">
                <label>Password</label>
                <input type="password" name="password" id="password" placeholder="Password" class="form-control" value="<?php echo e($password); ?>">
            </div>
            <div class="form-group">
            <label>Category</label>

            <select name="category" id="BodyPH_ddlInstituteID" class="form-control AspireDropDownList">
		            <option selected="selected" value="">Select</option>
		            
		            <option value="doctor">Doctor</option>
		            <option value="patient">Patient</option>
	                </select>
            <button onclick="document.location='login-form'">Register</button>
            <br>
            <?php echo csrf_field(); ?>
        </form>
        <a href="<?php echo e(url('login-form')); ?>" class="link">Already have an account? Login</a>
        <?php echo csrf_field(); ?>
    </div>
</body>
</html>
<?php /**PATH C:\Users\M Yousaf\Desktop\Install-Laravel\app\my_first_app\resources\views/register.blade.php ENDPATH**/ ?>
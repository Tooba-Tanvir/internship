<!DOCTYPE html>
<html>
<head>
    <title>View Your Appointments</title>
    <style>
        /* CSS styles */
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            background-color: #f9f9f9;
        }
        .table {
            width: 100%;
            margin-bottom: 20px;
            border-collapse: collapse;
        }
        .table th, .table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        .table th {
            background-color: #f2f2f2;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
        }
        .form-group input, .form-group textarea {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
        }
        .form-group textarea {
            resize: vertical;
        }
        .button {
            background-color: #4CAF50;
            border: none;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            cursor: pointer;
            border-radius: 8px;
            transition: background-color 0.3s, box-shadow 0.3s;
        }
        .button:hover {
            background-color: #45a049;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        .button:active {
            background-color: #3e8e41;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
            transform: translateY(2px);
        }
    </style>
</head>
<body>

<div class="container">
    <h2>View Your Appointments</h2>
    <table class="table">
        <thead>
            <tr>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Problem</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user->firstname); ?></td>
                <td><?php echo e($user->lastname); ?></td>
                <td><?php echo e($appointment->problem); ?></td>
                <td>
                    <form action="/appointments/<?php echo e($appointment->id); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="button">Open</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php if(session('success')): ?>
        <p><?php echo e(session('success')); ?></p>
    <?php endif; ?>

    <?php if(request()->isMethod('post')): ?>
        <h3>Appointment Details</h3>
        <form action="/appointment/<?php echo e(request()->segment(2)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="current_medication">Current Medication</label>
                <textarea id="current_medication" name="current_medication" required><?php echo e(old('current_medication')); ?></textarea>
            </div>
            <div class="form-group">
                <label for="allergies">Allergies</label>
                <textarea id="allergies" name="allergies"><?php echo e(old('allergies')); ?></textarea>
            </div>
            <div class="form-group">
                <label for="notes">Notes</label>
                <textarea id="notes" name="notes"><?php echo e(old('notes')); ?></textarea>
            </div>
            <button type="submit" class="button">Prescribe</button>
        </form>
    <?php endif; ?>
</div>

</body>
</html>
<?php /**PATH C:\Users\M Yousaf\Desktop\Install-Laravel\app\my_first_app\resources\views/appointment.blade.php ENDPATH**/ ?>
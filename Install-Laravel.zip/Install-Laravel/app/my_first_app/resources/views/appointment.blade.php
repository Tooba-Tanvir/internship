<!DOCTYPE html>
<html>
<head>
    <title>View Your Appointments</title>
    <style>
        /* CSS styles */
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            background-color: #f9f9f9;
        }
        .table {
            width: 100%;
            margin-bottom: 20px;
            border-collapse: collapse;
        }
        .table th, .table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        .table th {
            background-color: #f2f2f2;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
        }
        .form-group input, .form-group textarea {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
        }
        .form-group textarea {
            resize: vertical;
        }
        .button {
            background-color: #4CAF50;
            border: none;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            cursor: pointer;
            border-radius: 8px;
            transition: background-color 0.3s, box-shadow 0.3s;
        }
        .button:hover {
            background-color: #45a049;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        .button:active {
            background-color: #3e8e41;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
            transform: translateY(2px);
        }
    </style>
</head>
<body>

<div class="container">
    <h2>View Your Appointments</h2>
    <table class="table">
        <thead>
            <tr>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Problem</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($appointments as $appointment)
            <tr>
                <td>{{ $user->firstname }}</td>
                <td>{{ $user->lastname }}</td>
                <td>{{ $appointment->problem }}</td>
                <td>
                    <form action="/appointments/{{ $appointment->id }}" method="POST">
                        @csrf
                        <button type="submit" class="button">Open</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>

    @if (session('success'))
        <p>{{ session('success') }}</p>
    @endif

    @if (request()->isMethod('post'))
        <h3>Appointment Details</h3>
        <form action="/appointment/{{ request()->segment(2) }}" method="POST">
            @csrf
            <div class="form-group">
                <label for="current_medication">Current Medication</label>
                <textarea id="current_medication" name="current_medication" required>{{ old('current_medication') }}</textarea>
            </div>
            <div class="form-group">
                <label for="allergies">Allergies</label>
                <textarea id="allergies" name="allergies">{{ old('allergies') }}</textarea>
            </div>
            <div class="form-group">
                <label for="notes">Notes</label>
                <textarea id="notes" name="notes">{{ old('notes') }}</textarea>
            </div>
            <button type="submit" class="button">Prescribe</button>
        </form>
    @endif
</div>

</body>
</html>

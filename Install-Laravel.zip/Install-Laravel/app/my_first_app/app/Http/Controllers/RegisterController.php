<?php

namespace App\Http\Controllers;

use App\Models\UserModel;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
class RegisterController extends Controller
{
    public function loadregisterpage(){
        $firstname="";
        $lastname= "";
      //  $contact="";
        $password = "";
        $email = "";
        $username = "";
        $category="";
        return view('register',compact('username','password','email','firstname','lastname','category'));
    }
    public function storeuser(Request $request){
        // dd($request->username);//dd= display and die
        // dd($request->all());
        $object = new UserModel();
        $object->firstname=$request->firstname;
        $object->lastname=$request->lastname;
        $object->username = $request->username;
        $object->password = $request->password;
        $object->email= $request->email;
      //  $object->contact = $request->contact;
        $object->category=$request->category;
        $object->save();
       // return redirect()->route('register-view');
       return redirect()->route('login-view');
    }
}

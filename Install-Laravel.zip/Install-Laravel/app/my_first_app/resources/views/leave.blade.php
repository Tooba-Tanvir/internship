<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Container Example</title>
    <style>
        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .checkbox-container {
            display: flex;
            align-items: center;
        }

        .checkbox-container input[type="checkbox"] {
            margin-right: 5px;
        }

        .checkbox-container label {
             margin-right: 15px;
        }

    </style>
</head>
<body>
   
   
<div class="container">
    <h3>    Apply for leave</h3>
 <div class="checkbox-container">
  <input type="checkbox" id="checkbox1" name="checkbox1" value="value1">
  <label for="checkbox1">Full Time</label>
  
  <input type="checkbox" id="checkbox2" name="checkbox2" value="value2">
  <label for="checkbox2">Part Time</label>
</div>
<label>Alternate Number</label>
<input type="number" name="number" id="number" placeholder="Number" class="form-control">
</div>

<div class="container">
<div class="date-picker-container">
    <label for="date">Choose a date:</label>
    <input type="date" id="date" name="date">
  </div>
</div>
</body>
</html>
<?php
namespace App\Http\Controllers;
use App\Models\UserModel;
use Illuminate\Http\Request;
class DashboardController extends Controller
{
    public function loaddashboardpage(){
      $user = UserModel::all();

    
       // return view('login',compact('username','password'));
    }
    public function store_user(Request $request){
        // dd($request->username);//dd= display and die
        $user = UserModel::all();
      
      //  $object->save();
        //return redirect()->route('login-view');
    }
}

<?php

use App\Http\Controllers\LoginController;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\dashboardcontroller;

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AppointmentController;

Route::get('/appointments', [AppointmentController::class, 'index'])->middleware('auth');
Route::post('/appointments/{id}', [AppointmentController::class, 'update'])->middleware('auth');

/*
|--------------------------------------------------------------------------
| Web Routes
|------------------------------------------------------------------------
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
//register

Route::get('registeration-form',[RegisterController::class,"loadregisterpage"])->name("register-view");
Route::post('saveuser',[RegisterController::class,"storeuser"])->name("register-user");


//login
Route::get('login-form',[LoginController::class,"loadloginpage"])->name("login-view");
Route::post('loginuser',[LoginController::class,"loginuser"])->name("loginuser");

//dashboard


Route::get('dashboard-form',[dashboardcontroller::class,"loaddashboardpage"])->name("dashboard-view");
Route::get('dashboard-form',[dashboardcontroller::class,"store_user"])->name("dashboard-view");

Route::get("appointments",[AppointmentController::class,"getAppointments"]);


//Route::get('appointment-form', [AppointmentController::class, "index"])->name("appointment-view");
//Route::get('appointment-form{request,id}', [AppointmentController::class, "update"])->name("appointment-view");
//leave
Route::get('leave-form',function(){
  return view('leave');
});



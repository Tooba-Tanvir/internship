<?php
namespace App\Http\Controllers;
use App\Models\UserModel;
use Illuminate\Http\Request;
class LoginController extends Controller
{
    public function loadloginpage(){
        $username = "";
        $password = "";
        $category="";
//        $email = "";
//        $emailverified="";
//        $remember_tokken="";
        return view('login',compact('username','password','category'));
}

public function loginuser(Request $request){
        // dd($request->username);//dd= display and die
 $object = new UserModel();
 $object->username = $request->username;
//        $object->emailverified = $request->email_verified_at;
//        $object->email= $request->email;
       $object->password = $request->password;
//        $object->remember_token=$request->remember_token;
      // $object->save();
     // return redirect()->route('login-view');
     return redirect()->route('dashboard-view');
}

}
